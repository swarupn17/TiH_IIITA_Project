# 📱 Gesture Recognition Android App: Beginner's Guide

This folder contains the **Android App** that lets you view and control the gesture recognition system directly from your Android phone!

**You do not need to be a developer to install this app.** Just follow the steps below.

---

## 🛑 Important First Step
**Before you start, make sure your phone and your computer are connected to the exact same Wi-Fi network.** The app needs to communicate with the system running on your computer.

---

## 📥 Step 1: Install the App on Your Phone

You can choose to install the app by sending the file to yourself, or by plugging your phone into your computer. Choose the section below based on your computer (Mac or Windows).

### 🍎 For Mac Users (Via Cable)
1. Plug your Android phone into your Mac using a USB cable. 
*(Make sure your phone is unlocked and you tap "Allow" if it asks for permission).*
2. Open the **Terminal** app (search "Terminal" in Spotlight).
3. Type the following commands, pressing Enter after each one:
   ```bash
   cd Desktop/TiH_IIITA_Project-main/android-app
   ./gradlew installDebug
   ```
4. Look at your phone—the Gesture App will automatically open!

### 🪟 For Windows Users (Via Cable)
1. Plug your Android phone into your Windows PC using a USB cable. 
*(Make sure your phone is unlocked and you tap "Allow" if it asks for permission).*
2. Open the **Command Prompt** (search "cmd" in the Start Menu).
3. Tell it to go to the project folder by typing:
   ```cmd
   cd Desktop\TiH_IIITA_Project-main\android-app
   ```
   *(Press Enter)*
4. Type this command and press Enter:
   ```cmd
   gradlew.bat installDebug
   ```
5. Look at your phone—the Gesture App will automatically open!

### ✉️ Alternative: Install Without a Cable (Mac & Windows)
If you don't want to use a cable, the app file (the `.apk`) is already saved on your computer here:
`TiH_IIITA_Project-main/android-app/app/build/outputs/apk/debug/app-debug.apk`

1. Email this file to yourself, or send it to yourself on WhatsApp/Slack.
2. Open the file on your Android phone and tap **Install**.

---

## 🌐 Step 2: Connect the App (The URL Explained!)

When you open the Android app, it asks you for a **Server URL**. This is how the app knows where to look for the dashboard. 

**What URL do you type here?**
You need to type **your computer's IP address** and add `:3000` to the end of it.

* **Format:** `http://<YOUR_COMPUTER_IP_ADDRESS>:3000`
* **Example:** `http://192.168.1.100:3000`

### How to find your computer's IP Address:
* **On Mac:** Open Terminal and type `ipconfig getifaddr en0`. Press Enter.
* **On Windows:** Open Command Prompt and type `ipconfig`. Press Enter. Look for "IPv4 Address".

Once you type that URL into the app and tap **Connect**, the dashboard will load right on your phone!

---

## ❓ Troubleshooting

* **Error: Cannot reach server:** 
  1. Did you forget the `http://` part?
  2. Did you forget the `:3000` at the end?
  3. Is your phone on the *exact same Wi-Fi* as the computer?
  4. Is the main system actually running on your computer? (See the main project README to learn how to start it).
